USE Ecommerce;

INSERT INTO Sellers (SocialName, AbstractName, EntityType, CPF_CNPJ, Location, Contact) VALUES 
('EletroGamer Distribuidora Ltda', 'Mega Gamer Store','CNPJ', '98765432000101', 'São Paulo - SP', '11988887777'),
('Moda e Estilo Varejo Atacadista', 'Estilo Urbano','CNPJ', '87654321000102', 'Rio de Janeiro - RJ', '21977776666'),
('Comércio de Alimentos Aliança S.A.', 'Mercado Aliança','CNPJ', '76543210000103', 'Belo Horizonte - MG', '31966665555'),
('Brinquedos Criativos EIRELI', 'Espaço Infantil','CNPJ', '65432109000104', 'Curitiba - PR', '41955554444'),
('Mundo Digital Acessórios Eletrônicos', 'Mundo Tech','CNPJ', '54321098000105', 'Porto Alegre - RS', '51944443333'),
('Varejo Top Importados', 'Top Store','CNPJ', '43210987000106', 'Recife - PE', '81933332222'),
('Bazar e Papelaria Central', 'Bazar Central','CNPJ', '32109876000107', 'Salvador - BA', '71922221111'),
('Sabor da Terra Produtos Naturais', 'Nutri Terra','CNPJ', '21098765000108', 'Fortaleza - CE', '85911110000'),
('Esporte e Ação Equipamentos', 'Ação Sports','CNPJ', '10987654000109', 'Goiânia - GO', '62999998888'),
('Luz e Vida Decorações Ltda', 'Luz & Arte','CNPJ', '09876543000110', 'Manaus - AM', '92988889999'),
('Vanguard Soluções Comerciais', 'Vanguard Store','CNPJ', '11223344000122', 'Brasília - DF', '61977778888'),
('Sul Fashion Confecções', 'Sul Fashion','CNPJ', '22334455000133', 'Florianópolis - SC', '48966667777'),
('Oasis Distribuidora de Bebidas', 'Oasis Bebidas','CNPJ', '33445566000144', 'Aracaju - SE', '79955556666'),
('Carlos Eduardo Rodrigues', NULL,'CPF', '22233344401', 'Vitória - ES', '27944445555'),
('Mariana Souza Santos', NULL,'CPF', '33344455502', 'Cuiabá - MT', '65933334444'),
('Roberto Alves Oliveira', NULL,'CPF', '44455566603', 'Belém - PA', '91922223333'),
('Juliana Lima Ferreira', NULL,'CPF', '55566677704', 'Natal - RN', '84911112222'),
('Fernando Costa Almeida', NULL,'CPF', '66677788805', 'João Pessoa - PB', '83999990000'),
('Patricia Ribeiro Melo', NULL,'CPF', '77788899906', 'Teresina - PI', '86988881111'),
('Lucas Martins Carvalho', NULL,'CPF', '88899900007', 'São Luís - MA', '98977772222'),
('Camila Rocha Nascimento', NULL,'CPF', '99900011108', 'Maceió - AL', '82966663333'),
('Bruno Vieira Barbosa', NULL,'CPF', '00011122209', 'Campo Grande - MS', '67955554444'),
('Amanda Teixeira Ramos', NULL,'CPF', '11122233310', 'Palmas - TO', '63944445555'),
('Diego Henrique Silva', NULL,'CPF', '22233344411', 'Porto Velho - RO', '69933334444'),
('Letícia Gonçalves Dias', NULL,'CPF', '33344455512', 'Natal - RN', '84922223333');


SELECT * FROM Sellers;
