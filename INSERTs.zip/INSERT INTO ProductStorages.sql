USE Ecommerce;

INSERT INTO ProductStorages (StorageLocation) VALUES 
('São Paulo - SP'),
('Rio de Janeiro - RJ'),
('Belo Horizonte - MG'),
('Vitória - ES'),
('Recife - PE'),
('Salvador - BA'),
('Fortaleza - CE'),
('Curitiba - PR'),
('Goiânia - GO'),
('Manaus - AM');

SELECT * FROM ProductStorages;
